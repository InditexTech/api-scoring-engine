# amginspector-pr-verify

[`amginspector-PR_verify.yml`](../amginspector-PR_verify.yml) Workflow that verifies AMIGA inspector rules inside amginspector folder.

## Trigger

Any pull request when there are changes into `amginspector` path.

## Where does it run?

[github-runners](https://github.com/inditex/github-runners/tree/main/images/self-hosted/common) common self hosted.

## Jobs

- ### `amginspector-verify`

  - **Steps**
    - Checkout repo.
    - Checkout inditex actions repo.
    - Run [`amiga/inspector/verify`](https://github.com/inditex/actions/amiga/inspector/verify) action, in order to execute MS Application Inspector verifyrules over amginspector/rules folder.