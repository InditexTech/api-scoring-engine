# security-detect_secrets

[`security-detect_secrets.yml`](../security-detect_secrets.yml) analyze each push to the repository
and checks if there is any secrets in the changes uploaded.

## Trigger

* All `push` events that are not present in a protected branch (`main` and `develop`).
* Any `opened` pull request.

## Where does it run?

A `security` runner of the self-hosted
[github-runners](https://github.com/inditex/github-runners).

## Steps

### `Detect secrets`

Analyze the changes uploaded to the repository in order to find possible secrets.

### `Archive artifacts`

Archive the results related to the analysis in GitHub.

### `Notify the user`

In push events, if there is any finding notify the user with a comment in the latest commit of the push analyzed.
