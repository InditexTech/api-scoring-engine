# amginspector-analyzer

[`amginspector-analyzer.yml`](../amginspector-analyzer.yml) Workflow that runs [Microsoft Application Inspector](https://github.com/Microsoft/ApplicationInspector) in the project and uploads to AMIGA Inspector API in order to exploit the data in [AMIGA Inspector web](https://sscc.central.inditex.grp/amginspect/web).

## Trigger

- Every **push** over `develop` and `main` branches.
- In a **pull request** with `amiga-inspector` label.

## Where does it run?

[github-runners](https://github.com/inditex/github-runners/tree/main/images/self-hosted/common) common self hosted.


## Jobs

- ### `run-inspector`

  - **Steps**
    - Checkout repo.
    - Checkout [Inditex actions](https://github.com/inditex/actions) repo.  
    - Checkout [AMIGA inspector configuration](https://github.com/inditex/cac-amigainspectorrules) repo.  
    - Extract project name and key from `application.yml` file.
    - Extract config data from the configuration repo.
    - Extract, if exists, project config data form amginspector folder.
    - Merge project and global config, using project config values if exists over the global. In case of `exclusions` field, the local config will be concatenated to global exclusions.
    - Extract branch name.
    - Copy global rules from configuration repo and from amginspector/rules folder to a new rulesFolder.
    - Run [`amiga/inspector/run`](https://github.com/inditex/actions/amiga/inspector/run) in order to run MS Application Inspector analyze over de project code.