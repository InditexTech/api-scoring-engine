#/usr/bin/env bash

cwd=$PWD
BAD_FILE='examples/bad.*'
GOOD_FILE='examples/good.*'
ERROR=0

# Testing proto with protolint

cd ..\/proto

RES="$(protolint lint -config_dir_path rules $BAD_FILE 2>&1 | wc -l)"
if [ $RES -ge 1 ]; then
  echo "Passed: proto/$BAD_FILE are invalid proto (got $RES errors)"; else
  ERROR=1 && echo "Failed: Invalid proto test (got 0 errors)";
fi

RES="$(protolint lint -config_dir_path rules $GOOD_FILE 2>&1 | wc -l)"

if [ $RES -eq 0 ]; then
  echo "Passed: proto/$GOOD_FILE are valid proto"; else
  ERROR=1 && echo "Failed: Valid proto test (no errors expected, got $RES)";
fi

# Testing JSON based with spectral

for protocol in avro asyncapi openapi; do
  cd $cwd
  cd ..\/$protocol

  RES="$(spectral lint $BAD_FILE -r rules/itx-spectral.yaml | sed -rn 's/.*\(([0-9]+) error.*/\1/gp')"
  if [ ${RES} -ge 1 ]; then
    echo "Passed: $protocol/$BAD_FILE are invalid $protocol (got $RES errors)"; else
    ERROR=1 && echo "Failed: $BAD_FILE are actually invalid $protocol (got 0 errors)";
  fi

  RES="$(spectral lint $GOOD_FILE -r rules/itx-spectral.yaml | sed -rn 's/.*\(([0-9]+) error.*/\1/gp')"
  if [ -z $RES ] || [ ${RES} -eq 0 ]; then
    echo "Passed: $protocol/$GOOD_FILE are valid $protocol"; else
    ERROR=1 && echo "Failed: $GOOD_FILE are actually invalid $protocol (no errors expected, got $RES)";
  fi

done

exit $ERROR
