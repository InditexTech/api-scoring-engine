/**
  * Ensure that both Basic & Bearer authentication is supported
  */
 
/*  module.exports =(item, _, paths) => {
    
    for(var key in item.servers){
        if (item.info.version.substring(0,1) != item.servers[key].url.substring(item.servers[key].url.length - 1)) {
          //console.log("debug", context.path)
            return [
              {
                message: `url version should be v${item.info.version.substring(0,1)}`,
              }
            ]
        }
    }
  } */

  export default (input, options, { path } ) => {

    for(var key in input.servers){
      if (input.info.version.substring(0,1) != input.servers[key].url.substring(input.servers[key].url.length - 1)) {
          return [
            {
              message: `url version should be v${input.info.version.substring(0,1)}`,
              path: ['servers']
              
            }
          ]
      }
    }
  };