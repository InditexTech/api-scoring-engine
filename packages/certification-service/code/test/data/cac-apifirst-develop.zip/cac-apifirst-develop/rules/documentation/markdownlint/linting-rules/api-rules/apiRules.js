// @ts-check

"use strict";

const mandatoryAbout = require("./api-mandatory-about");
const mandatoryConfiguration = require("./api-mandatory-configuration");
const mandatoryDocumentation = require("./api-mandatory-documentation");
const mandatoryExample = require("./api-mandatory-example");
const mandatoryMainGoal = require("./api-mandatory-main-goal");
const mandatorySpecifics = require("./api-mandatory-specifics");
const mandatoryUsage = require("./api-mandatory-usage");
const defaultReadme = require("./api-default-readme");

module.exports.all = [
  mandatoryAbout,
  mandatoryConfiguration,
  mandatoryDocumentation,
  mandatoryExample,
  mandatoryMainGoal,
  mandatorySpecifics,
  mandatoryUsage,
  defaultReadme
];