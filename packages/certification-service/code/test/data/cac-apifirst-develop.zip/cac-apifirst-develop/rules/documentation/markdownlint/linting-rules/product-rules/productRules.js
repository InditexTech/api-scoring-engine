// @ts-check

"use strict";

const mandatoryGettingStarted = require("./product-mandatory-getting-started");
const mandatorySummary = require("./product-mandatory-summary");
const mandatorySupport = require("./product-mandatory-support");
const defaultReadme = require("./product-default-readme");

module.exports.all = [
  mandatoryGettingStarted,
  mandatorySummary,
  mandatorySupport,

  defaultReadme
];