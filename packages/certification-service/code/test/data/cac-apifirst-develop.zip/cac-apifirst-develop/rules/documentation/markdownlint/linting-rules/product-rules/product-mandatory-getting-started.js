// @ts-check
"use strict";

const sectionName = "getting started"

module.exports = {
  "names": [ "EX_MD060", "inditex-mandatory-getting-started"],
  "description": "Mandatory Getting Started Section",
  "information": new URL(
    "https://axinic.central.inditex.grp/confluence/display/ArqSoft/Markdown+Rules"
  ),
  "tags": [ "Sections" ],
  "function": function rule(params, onError) {
    var headerExists = false;
    params.tokens.filter(function filterToken(token) {
      return token.type === "inline";
    }).forEach(function forToken(inline) {
      inline.children.filter(function filterChild(child) {
        return child.type === "text";
      }).forEach(function forChild(text) {
        if(text.line.startsWith("#")){
          if(text.line.trim().toLowerCase().includes(sectionName)){
            headerExists = true;
          }
        }
      });
    });
    if(!headerExists){
      onError({
        "lineNumber": 1,
        "context": `Section '${sectionName}' must exist`
      });
    }
  }
};