# How to use this repository

This repository contains default linter configuration for several formats adopted at Inditex.

Each format has its own configuration folder. In some cases there is a global settings file that needs to be present in your API base folder. In other cases is just a rules files that may be passed as a parameter.

These configuration files rules are the ones applied in the continous integration flow so its recommended to use them in the local development flow for validation.

For more information on how linting becomes a key element in the CI pipeline please read API First section at [Developer Portal](https://axinic.central.inditex.grp/devportal/).

> **_REMEMBER:_** You need to FORK this repo in order to make pull requests

## OpenAPI (and other JSON equivalent formats)

### Spectral

> **_NOTE:_** The rules added here are for *[Spectral 5.9.2](https://www.npmjs.com/package/@stoplight/spectral/v/5.9.2)* version. If you are using the latest version, you might find issues until we upgrade the rulesets (they're not backward compatible)

[Spectral](https://github.com/stoplightio/spectral) is a linting tool that provides flexibility for defining custom rules. It supports OAS2, OAS3 and custom formats.
This tool is used at Inditex for linting these formats:

- swagger & openapi, at [openapi/rules/itx-spectral.yaml](./openapi/rules/itx-spectral.yaml)
- asyncapi, at [asyncapi/rules/itx-spectral.yaml](asyncapi/rules/itx-spectral.yaml)
- avro, at [avro/rules/itx-spectral.yaml](avro/rules/itx-spectral.yaml)

Using Spectral is straightforward:

```bash
$> spectral lint YOUR_OPENAPI_DEFINITION -r THIS_REPO/openapi/rules/itx-spectral.yaml
```

![Spectral Example](images/spectral-example.png)

## Protobuf

### Protolint

[Protolint](https://github.com/yoheimuta/protolint) provides more robust support for proto definitions. It will be the default tool used in the Inditex PRVerify pipeline.

```bash
$> protolint lint --config_dir_path=THIS_REPO/proto YOUR_PROTO_FILE_OR_FOLDER
```  

> INFO: Rules applied to gRPC proto files are based on [Google Style](https://developers.google.com/protocol-buffers/docs/style) ones.


If you find that your lines are too long and breaking into new lines doesnt work please use this workaround:


```proto
 rpc UpdateLinesQuantity (Request)
    returns (Response)
 { //Add this opening
 } //and this closing brackets
```

## Testing

There is a small utility for testing any rule changes over a set of files. Set your current DIR to `test` and then execute `$> ./test.sh`. For example:

```bash
$> cd test 
$> ./test.sh
Passed: proto/examples/bad.* are invalid proto (got 2 errors)
Passed: proto/examples/good.* are valid proto
Passed: avro/examples/bad.* are invalid avro (got 4 errors)
Passed: avro/examples/good.* are valid avro
Passed: asyncapi/examples/bad.* are invalid asyncapi (got 1 errors)
Passed: asyncapi/examples/good.* are valid asyncapi
Passed: openapi/examples/bad.* are invalid openapi (got 16 errors)
Passed: openapi/examples/good.* are valid openapi
```

## Output Interpretation

### Spectral

Spectral will output detailed information on each linting rule being violated. For instance, the total number of problems means that errors, warnings and info are summed up.
As a general rule, Inditex APIs pipeline will only take errors as failure. Warnings are info problems will only be shown as an output log.

### Protolint

Protolint doesn't support distinguinshing between warnings and errors. Any output in protolint execution is interpreted as a linting error.
You may ignore inherited linting errors (such as bad indexed enums) using [protolint support for disabling rules](https://github.com/yoheimuta/protolint).
