module.exports = (targetVal) => {
    let results = [];

    for(let api of targetVal.apis){
        const protocol = api["api-spec-type"];
        const apiName = api["name"];
    
        if(apiName.toLowerCase().includes(protocol)){
            results.push({
                message: 'apiName must not contain protocol.',
                path: ['api', apiName],
              });
        }
    }
   
  
    return results;
  };