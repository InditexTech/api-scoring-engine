# Custom Ruleset 

This README explains **how to create a custom ruleset** so that you can validate your files with a specific self-created ruleset.
Know that there is an example under the [**example**](./example/) folder in case you need further information.

## How to create a ruleset

The best way to create a custom ruleset is to follow [these guidelines](https://meta.stoplight.io/docs/spectral/e5b9616d6d50c-custom-rulesets). 

## Where to place the custom ruleset

You should always follow the structure given in the example, which is:

```
├── file-rules
│   ├── <ruleset_name>
│       └── itx-spectral-ruleset.yml
```

Notice that you can add Javascript functions to the YAML file, which will enrich the power of your ruleset.