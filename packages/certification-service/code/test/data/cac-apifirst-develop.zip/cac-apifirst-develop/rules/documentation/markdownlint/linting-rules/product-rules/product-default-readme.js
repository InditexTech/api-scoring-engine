// @ts-check
"use strict";
 
const fs = require('fs');

const fileUrl = "/product-default-readme.md";
const path = require("path");

var file_content = fs.readFileSync(__dirname + fileUrl, 'utf8').toString().split("\n");

module.exports = {
  "names": [ "EX_MD059", "inditex-product-default-readme"],
  "description": "Please update the Product default readme",
  "information": new URL(
    "https://axinic.central.inditex.grp/confluence/display/ArqSoft/Markdown+Rules"
  ),
  "tags": [ "Default" ],
  "function": function rule(params, onError) {
    var isLineEqual = true;
    params.lines.forEach(function forChild(line, i) {
      if(line != file_content[i] && isLineEqual){
        isLineEqual = false;
      }
     
    }, this);
    
    if(isLineEqual){
      onError({
        "lineNumber": 1,
        "context": `Please update the default Readme`
      });
    }
  }
};
