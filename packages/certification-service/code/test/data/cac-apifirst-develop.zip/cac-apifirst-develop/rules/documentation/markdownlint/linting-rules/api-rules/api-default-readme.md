## ABOUT

Describe your product or API in a way that anyone would quickly understand it, what it is, what type of product or API it is, and for what it is used.
Special attention must be paid into describing the **purpose** of the product or the API, the problem it aims to solve.
Also, make sure to specify the **audience**: team, area, or company.

### MAIN GOAL

The bigger business or functional need that justifies the product's or API's existence.
For products or APIs that have a direct consequence into business applications, this main goal will ultimately be ensuring the sales or business process. But, for functional products or APIs this main goal may be not so straightforward. Make sure you describe **"why it is important that this product or API delivers"**.

### CONTEXT
(if applies)

If this product or API is part of a bigger project or ecosystem, explain how this product or API makes sense in that bigger context. Also, briefly describe the other pieces that make up the whole picture.

Provide direct links to these other products, APIs, and tools. It may also be interesting to specify the API roles: adapter, composite, core, etc.

The use of diagram flows is advised.

### SPECIFICS

Specify to which **protocol** or **protocols** this product or API applies.
Also, include any keep-in-mind notes that you believe necessary for describing the product or the API.

## USAGE

Include any notes and specifications (for example, authorizations) the product or API consumers needs to bear in mind before invoking them.
Regarding the API README, describe the previous context needed for invoking this API (other APIs that had to be invoked first) and the following steps that may apply.
The use of flow diagrams is advised.

### CONFIGURATION

Describe which **main customizations** this product or API will allow for and that the API consumer will like to know at this (initial) stage.

### EXAMPLE

Provide a simple product's or API's use example (or use case).

## DOCUMENTATION

You can use this space to include any other information you believe is relevant and does not fit in any of the previous sections.
More specifically, you may want to:

- Specify the most-relevant properties, for clarity purposes.
- Provide direct links to documentation.
- Provide a contact e-mail address so that product or API consumers can directly request more information.