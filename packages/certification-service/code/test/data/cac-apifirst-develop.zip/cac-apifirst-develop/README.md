# How to use this repository
This repository contains several folders, each one have a different functionality.
Below is a summary the differents functionality


# rules folder

This repository contains default linter configuration for several formats adopted at Inditex.

Each format has its own configuration folder. In some cases there is a global settings file that needs to be present in your API base folder. In other cases is just a rules files that may be passed as a parameter.

This configuration files rules are the ones applied in the continous integration flow so its 
recommended to use them in the local development flow for validation.

For more information on how linting becomes a key element in the CI pipeline please read API First section at [Developer Portal](https://axinic.central.inditex.grp/devportal/).

More information [README.md](rules/README.md)

> **_REMEMBER:_** You need to FORK this repo in order to make pull requests


# api-taxonomy folder
This folder is used for define the APIs domains and groups for the API Portal.

# action folder
This folder contains the code for execute the workflows validations.

# scripts folder
This folder contains scripts to test projects in local environment
